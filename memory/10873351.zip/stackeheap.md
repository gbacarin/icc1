#Stack e Heap

	Heap e stack são diferentes formas de uso de memória por um programa.

##Stack:
	é uma região da memória cujo tamanho é conhecido no momento da compilação e não varia durante a execução do programa; nela, as funções, estruturas e variáveis são empilhadas umas sobre as outras na ordem em que aparecem no programa, sendo as mais recentes as que estão "por cima", na forma "last in first out". (variáveis globais não ficam na stack, e sim em outro segmento de memória próprio).

	A stack é uma região contígua da memória, e o próximo espaço livre é indicado por um apontador. Um exemplo do que acontece na stack durante a execução de um programa é o seguinte:

	* apontador na posição 0
	* Função main inicia
	* variáveis locais de main colocadas na stack
	* apontador se move para a próxima região livre (posição 1)
	* função f1() é chamada
	* variáveis de f1 são colocadas na stack na posição 1
	* apontador se move para a próxima região livre (posição 2)
	* função f2() é chamada
	* variáveis de f2 são colocadas na stack na posição 2
	* apontador se move para próxima região livre (posição 3)
	* função f2 retorna seus valores
	* apontador retrocede para a posição 2
	* função f1 retorna seus valores
	* apontador retrocede para a posição 1
	* main encerra
	* apontador volta para a posição 0

	O stack overflow ocorre quando se tenta alocar algo na stack e não se tem mais espaço nela para isso. Costuma acontecer quando há muitas chamadas recursivas

##Heap:
	são diversas regiões pequenas da memória. O heap é dinâmico e seu tamanho varia de acordo com as necessidades da aplicação. Fisicamente, o heap pode ser alocado em qualquer região disponível da memória, sendo normalmente alocado em múltiplos blocos de tamanhos fixos chamados páginas.

	A heap tem um custo de alocação e manutenção relativamente alto em termos de processamento, uma vez que o processador precisa manter listas que dizem onde cada coisa está alocada nela - algo mais complexo do que o apontador da stack.

	O acesso à heap é realizado através de ponteiros, sejam eles manipuláveis pelo programador ou implícitos na linguagem. As coisas são alocadas na heap quando o tamanho delas pode ser grande demais para estar na memória stack. Uma referência do que foi criado na heap pode estar na stack.

##Quais as principais diferenças entre Stack e Heap?
	* A stack tem tamanho pré definido na hora da execução, enquanto a heap tem tamanho variável
	* a stack é contígua, enquanto a heap pode ser fragmentada
	* o acesso à stack é feito por um apontador que indica onde ela termina, enquanto a heap é acessada por ponteiros e demanda que se mantenham listas de onde cada coisa está alocada

##Como é organizado o armazenamento na Stack? O armazenamento na Heap é feito da mesma forma?
	O armazenamento na stack é feito de forma linear e na lógica last in first out; o armazenamento na heap não precisa ser linear, apesar de tentar ser feito de forma menos fragmentada possível

##As duas segmentações da memória diferem muito em tamanho (ou capacidade de armazenamento)?
	O tamanho padrão da stack depende do sistema operacional usado; a heap supostamente pode ter qualquer tamanho que a RAM comportar

##Em que situações é aconselhável que utilizemos a memória Stack? E a memória Heap?
	A stack deve ser usada quando seu tamanho não for excedido, quando se precisa de um acesso mais rápido e quando não se tem a preocupação em desalocar. A heap é usada para coisas muito grandes para a stack e quando o local em que cada coisa está armazenada importar

##Existem prejuízos em abusar da memória Stack?
	Ocorre o stack overflow caso a memória stack seja usada além da sua capacidade